Thanks for downloading BlackWood free wordpress theme.

please post as a comment in http://www.skinpress.com/blackwood-wp-template/ for support related queries.

Thanks

http://www.skinpress.com