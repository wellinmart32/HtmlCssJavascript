<?
/**
 * @package WordPress
 * @subpackage magazine_obsession
 */

require_once('fn-admin.php');
require_once('obwp-settings.php');
require_once('obwp-settings-banners.php');
require_once('obwp-settings-pages.php');

add_action('admin_menu', 'obwp_add_menu'); 
 
?>